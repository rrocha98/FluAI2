import React from 'react';
import { FaWhatsapp } from 'react-icons/fa';

export default function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-8 bg-gradient-to-br from-blue-100 to-white">
      <h1 className="text-4xl font-bold text-center mb-4">FluAi</h1>
      <p className="text-xl text-center mb-6">Você fluente, com AI</p>
      <p className="text-center text-gray-700 mb-8 max-w-xl">
        Aprenda idiomas com inteligência artificial pelo WhatsApp!
      </p>

      <form className="w-full max-w-md bg-white p-6 rounded-2xl shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">Cadastre-se para saber mais</h2>
        <input type="text" placeholder="Nome" className="w-full mb-3 p-2 border rounded" />
        <input type="email" placeholder="E-mail" className="w-full mb-3 p-2 border rounded" />
        <input type="text" placeholder="Idioma de interesse" className="w-full mb-4 p-2 border rounded" />
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition">
          Enviar
        </button>
      </form>

      <a href="https://wa.me/5527998229177" target="_blank" rel="noopener noreferrer"
        className="flex items-center gap-2 text-white bg-green-500 px-4 py-2 rounded-full shadow-lg hover:bg-green-600 transition">
        <FaWhatsapp className="text-xl" />
        Falar no WhatsApp
      </a>
    </div>
  );
}
